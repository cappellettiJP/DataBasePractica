public class statement {

    public String sql;



}
